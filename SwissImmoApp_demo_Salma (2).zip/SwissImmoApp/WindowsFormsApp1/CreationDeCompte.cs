﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frm_CreationDeCompte : Form
    {
        public frm_CreationDeCompte()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n;
            bool isNumeric = int.TryParse(txt_telephone.Text, out n);
            if (!txt_email.Text.Contains("@")) {
                MessageBox.Show("Adresse mail invalide.","Erreur de saisie",  MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (!isNumeric)
            {
                MessageBox.Show("Numéro de téléphone invalide.", "Erreur de saisie", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if(txt_motDePasse.Text != txt_confirmerMotDePasse.Text)
            {
                MessageBox.Show("Le mot de passe ne correspond pas.", "Erreur de saisie", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (!chk_conditions.Checked) {
                MessageBox.Show("Veuillez accepter nos conditions générales.", "Votre accord est requis", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }

            ajouter_user();



        }

        private void txt_prenom_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_telephone_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmb_civilite_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void ajouter_user()
        {
            frm_espace_admin admin = new frm_espace_admin();
            string civilite = getCivilite();
            string nom = getNom();
            string prenom = getPrenom();
            string email = getEmail();
            string telephone = getTelephone();


            admin.addUser(civilite, nom, prenom, email, telephone);
            admin.Show();

        }
        public string getCivilite() {return cmb_civilite.Text;}

        public string getNom() { return txt_nom.Text; }
        public string getPrenom() { return txt_prenom.Text; }

        public string getEmail() { return txt_email.Text; }

        public string getTelephone() { return txt_telephone.Text.ToString(); }
    }
}
