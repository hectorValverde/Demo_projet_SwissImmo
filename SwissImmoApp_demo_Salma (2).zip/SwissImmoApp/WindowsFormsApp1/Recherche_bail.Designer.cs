﻿
namespace WindowsFormsApp1
{
    partial class frm_Recherche_bail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Recherche_bail));
            this.txt_titre = new System.Windows.Forms.TextBox();
            this.rdo_acheter = new System.Windows.Forms.RadioButton();
            this.rdo_location = new System.Windows.Forms.RadioButton();
            this.txt_nbPersonnes = new System.Windows.Forms.TextBox();
            this.txt_pices = new System.Windows.Forms.TextBox();
            this.cmb_nbPieces = new System.Windows.Forms.ComboBox();
            this.txt_type_bien = new System.Windows.Forms.TextBox();
            this.rdo_appartement = new System.Windows.Forms.RadioButton();
            this.rdo_maison = new System.Windows.Forms.RadioButton();
            this.rdo_commercial = new System.Windows.Forms.RadioButton();
            this.btn_rechercher = new System.Windows.Forms.Button();
            this.nud_nbPersonnes = new System.Windows.Forms.NumericUpDown();
            this.grp_radios_personnes = new System.Windows.Forms.GroupBox();
            this.grp_type_bien = new System.Windows.Forms.GroupBox();
            this.trb_loyer = new System.Windows.Forms.TrackBar();
            this.txt_indication = new System.Windows.Forms.TextBox();
            this.lbl_montant = new System.Windows.Forms.Label();
            this.txt_budget = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nud_nbPersonnes)).BeginInit();
            this.grp_radios_personnes.SuspendLayout();
            this.grp_type_bien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trb_loyer)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_titre
            // 
            this.txt_titre.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_titre.Enabled = false;
            this.txt_titre.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_titre.Location = new System.Drawing.Point(12, 24);
            this.txt_titre.Multiline = true;
            this.txt_titre.Name = "txt_titre";
            this.txt_titre.ReadOnly = true;
            this.txt_titre.Size = new System.Drawing.Size(235, 77);
            this.txt_titre.TabIndex = 0;
            this.txt_titre.Text = "Informations générales\r\n\r\nRechercher en tant que :";
            this.txt_titre.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // rdo_acheter
            // 
            this.rdo_acheter.AutoSize = true;
            this.rdo_acheter.Location = new System.Drawing.Point(11, 19);
            this.rdo_acheter.Name = "rdo_acheter";
            this.rdo_acheter.Size = new System.Drawing.Size(53, 17);
            this.rdo_acheter.TabIndex = 1;
            this.rdo_acheter.TabStop = true;
            this.rdo_acheter.Text = "Achat";
            this.rdo_acheter.UseVisualStyleBackColor = true;
            this.rdo_acheter.CheckedChanged += new System.EventHandler(this.rdo_acheter_CheckedChanged);
            // 
            // rdo_location
            // 
            this.rdo_location.AutoSize = true;
            this.rdo_location.Location = new System.Drawing.Point(140, 19);
            this.rdo_location.Name = "rdo_location";
            this.rdo_location.Size = new System.Drawing.Size(66, 17);
            this.rdo_location.TabIndex = 2;
            this.rdo_location.TabStop = true;
            this.rdo_location.Text = "Location";
            this.rdo_location.UseVisualStyleBackColor = true;
            this.rdo_location.CheckedChanged += new System.EventHandler(this.rdo_location_CheckedChanged);
            // 
            // txt_nbPersonnes
            // 
            this.txt_nbPersonnes.BackColor = System.Drawing.SystemColors.Control;
            this.txt_nbPersonnes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_nbPersonnes.Enabled = false;
            this.txt_nbPersonnes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nbPersonnes.Location = new System.Drawing.Point(12, 171);
            this.txt_nbPersonnes.Name = "txt_nbPersonnes";
            this.txt_nbPersonnes.Size = new System.Drawing.Size(142, 13);
            this.txt_nbPersonnes.TabIndex = 3;
            this.txt_nbPersonnes.Text = "Nombre de personnes :";
            // 
            // txt_pices
            // 
            this.txt_pices.BackColor = System.Drawing.SystemColors.Control;
            this.txt_pices.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_pices.Enabled = false;
            this.txt_pices.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pices.Location = new System.Drawing.Point(12, 219);
            this.txt_pices.Name = "txt_pices";
            this.txt_pices.Size = new System.Drawing.Size(202, 13);
            this.txt_pices.TabIndex = 5;
            this.txt_pices.Text = "Nombre de pièces souhaitées  : ";
            // 
            // cmb_nbPieces
            // 
            this.cmb_nbPieces.FormattingEnabled = true;
            this.cmb_nbPieces.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "Plus"});
            this.cmb_nbPieces.Location = new System.Drawing.Point(220, 216);
            this.cmb_nbPieces.Name = "cmb_nbPieces";
            this.cmb_nbPieces.Size = new System.Drawing.Size(97, 21);
            this.cmb_nbPieces.TabIndex = 8;
            this.cmb_nbPieces.Text = "Nb pièces";
            // 
            // txt_type_bien
            // 
            this.txt_type_bien.BackColor = System.Drawing.SystemColors.Control;
            this.txt_type_bien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_type_bien.Enabled = false;
            this.txt_type_bien.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_type_bien.Location = new System.Drawing.Point(12, 262);
            this.txt_type_bien.Name = "txt_type_bien";
            this.txt_type_bien.Size = new System.Drawing.Size(263, 13);
            this.txt_type_bien.TabIndex = 9;
            this.txt_type_bien.Text = "Quel type de bien souhaitez vous trouver ?";
            // 
            // rdo_appartement
            // 
            this.rdo_appartement.AutoSize = true;
            this.rdo_appartement.Location = new System.Drawing.Point(6, 15);
            this.rdo_appartement.Name = "rdo_appartement";
            this.rdo_appartement.Size = new System.Drawing.Size(85, 17);
            this.rdo_appartement.TabIndex = 10;
            this.rdo_appartement.TabStop = true;
            this.rdo_appartement.Text = "Appartement";
            this.rdo_appartement.UseVisualStyleBackColor = true;
            // 
            // rdo_maison
            // 
            this.rdo_maison.AutoSize = true;
            this.rdo_maison.Location = new System.Drawing.Point(97, 15);
            this.rdo_maison.Name = "rdo_maison";
            this.rdo_maison.Size = new System.Drawing.Size(59, 17);
            this.rdo_maison.TabIndex = 11;
            this.rdo_maison.TabStop = true;
            this.rdo_maison.Text = "Maison";
            this.rdo_maison.UseVisualStyleBackColor = true;
            // 
            // rdo_commercial
            // 
            this.rdo_commercial.AutoSize = true;
            this.rdo_commercial.Location = new System.Drawing.Point(162, 15);
            this.rdo_commercial.Name = "rdo_commercial";
            this.rdo_commercial.Size = new System.Drawing.Size(107, 17);
            this.rdo_commercial.TabIndex = 12;
            this.rdo_commercial.TabStop = true;
            this.rdo_commercial.Text = "Local commercial";
            this.rdo_commercial.UseVisualStyleBackColor = true;
            // 
            // btn_rechercher
            // 
            this.btn_rechercher.Location = new System.Drawing.Point(613, 407);
            this.btn_rechercher.Name = "btn_rechercher";
            this.btn_rechercher.Size = new System.Drawing.Size(123, 40);
            this.btn_rechercher.TabIndex = 13;
            this.btn_rechercher.Text = "Soumettre la recherche";
            this.btn_rechercher.UseVisualStyleBackColor = true;
            // 
            // nud_nbPersonnes
            // 
            this.nud_nbPersonnes.Location = new System.Drawing.Point(178, 169);
            this.nud_nbPersonnes.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_nbPersonnes.Name = "nud_nbPersonnes";
            this.nud_nbPersonnes.Size = new System.Drawing.Size(82, 20);
            this.nud_nbPersonnes.TabIndex = 14;
            // 
            // grp_radios_personnes
            // 
            this.grp_radios_personnes.BackColor = System.Drawing.Color.Transparent;
            this.grp_radios_personnes.Controls.Add(this.rdo_location);
            this.grp_radios_personnes.Controls.Add(this.rdo_acheter);
            this.grp_radios_personnes.Location = new System.Drawing.Point(12, 100);
            this.grp_radios_personnes.Name = "grp_radios_personnes";
            this.grp_radios_personnes.Size = new System.Drawing.Size(248, 47);
            this.grp_radios_personnes.TabIndex = 15;
            this.grp_radios_personnes.TabStop = false;
            // 
            // grp_type_bien
            // 
            this.grp_type_bien.Controls.Add(this.rdo_appartement);
            this.grp_type_bien.Controls.Add(this.rdo_maison);
            this.grp_type_bien.Controls.Add(this.rdo_commercial);
            this.grp_type_bien.Location = new System.Drawing.Point(12, 281);
            this.grp_type_bien.Name = "grp_type_bien";
            this.grp_type_bien.Size = new System.Drawing.Size(283, 40);
            this.grp_type_bien.TabIndex = 18;
            this.grp_type_bien.TabStop = false;
            // 
            // trb_loyer
            // 
            this.trb_loyer.LargeChange = 500;
            this.trb_loyer.Location = new System.Drawing.Point(12, 375);
            this.trb_loyer.Maximum = 20000;
            this.trb_loyer.Minimum = 1500;
            this.trb_loyer.Name = "trb_loyer";
            this.trb_loyer.Size = new System.Drawing.Size(335, 45);
            this.trb_loyer.SmallChange = 500;
            this.trb_loyer.TabIndex = 10;
            this.trb_loyer.TickFrequency = 1000;
            this.trb_loyer.Value = 1500;
            this.trb_loyer.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // txt_indication
            // 
            this.txt_indication.BackColor = System.Drawing.SystemColors.Control;
            this.txt_indication.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_indication.Enabled = false;
            this.txt_indication.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_indication.Location = new System.Drawing.Point(12, 338);
            this.txt_indication.Multiline = true;
            this.txt_indication.Name = "txt_indication";
            this.txt_indication.Size = new System.Drawing.Size(191, 31);
            this.txt_indication.TabIndex = 19;
            this.txt_indication.Text = "Veuillez s\'il vous plaît indiquer un prix (de location/mois)";
            // 
            // lbl_montant
            // 
            this.lbl_montant.AutoSize = true;
            this.lbl_montant.Enabled = false;
            this.lbl_montant.Location = new System.Drawing.Point(20, 421);
            this.lbl_montant.Name = "lbl_montant";
            this.lbl_montant.Size = new System.Drawing.Size(0, 13);
            this.lbl_montant.TabIndex = 20;
            this.lbl_montant.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txt_budget
            // 
            this.txt_budget.Location = new System.Drawing.Point(209, 335);
            this.txt_budget.Name = "txt_budget";
            this.txt_budget.Size = new System.Drawing.Size(96, 20);
            this.txt_budget.TabIndex = 21;
            this.txt_budget.Visible = false;
            this.txt_budget.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // frm_Recherche_bail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 477);
            this.Controls.Add(this.txt_budget);
            this.Controls.Add(this.lbl_montant);
            this.Controls.Add(this.txt_indication);
            this.Controls.Add(this.trb_loyer);
            this.Controls.Add(this.grp_type_bien);
            this.Controls.Add(this.grp_radios_personnes);
            this.Controls.Add(this.nud_nbPersonnes);
            this.Controls.Add(this.btn_rechercher);
            this.Controls.Add(this.txt_type_bien);
            this.Controls.Add(this.cmb_nbPieces);
            this.Controls.Add(this.txt_pices);
            this.Controls.Add(this.txt_nbPersonnes);
            this.Controls.Add(this.txt_titre);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_Recherche_bail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chercher un logement";
            ((System.ComponentModel.ISupportInitialize)(this.nud_nbPersonnes)).EndInit();
            this.grp_radios_personnes.ResumeLayout(false);
            this.grp_radios_personnes.PerformLayout();
            this.grp_type_bien.ResumeLayout(false);
            this.grp_type_bien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trb_loyer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_titre;
        private System.Windows.Forms.RadioButton rdo_acheter;
        private System.Windows.Forms.RadioButton rdo_location;
        private System.Windows.Forms.TextBox txt_nbPersonnes;
        private System.Windows.Forms.TextBox txt_pices;
        private System.Windows.Forms.ComboBox cmb_nbPieces;
        private System.Windows.Forms.TextBox txt_type_bien;
        private System.Windows.Forms.RadioButton rdo_appartement;
        private System.Windows.Forms.RadioButton rdo_maison;
        private System.Windows.Forms.RadioButton rdo_commercial;
        private System.Windows.Forms.Button btn_rechercher;
        private System.Windows.Forms.NumericUpDown nud_nbPersonnes;
        private System.Windows.Forms.GroupBox grp_radios_personnes;
        private System.Windows.Forms.GroupBox grp_type_bien;
        public System.Windows.Forms.TrackBar trb_loyer;
        private System.Windows.Forms.TextBox txt_indication;
        private System.Windows.Forms.Label lbl_montant;
        private System.Windows.Forms.TextBox txt_budget;
    }
}