﻿
namespace WindowsFormsApp1
{
    partial class frm_FenetreDeConnexion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_FenetreDeConnexion));
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_mdp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_bienvenue = new System.Windows.Forms.Label();
            this.lbl_instruction = new System.Windows.Forms.Label();
            this.btn_identifier = new System.Windows.Forms.Button();
            this.btn_creer_compte = new System.Windows.Forms.Button();
            this.btn_identifier_admin = new System.Windows.Forms.Button();
            this.btn_mdp_oublie = new System.Windows.Forms.Button();
            this.lbl_mail = new System.Windows.Forms.Label();
            this.lbl_mdp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_email
            // 
            this.txt_email.AcceptsTab = true;
            this.txt_email.Location = new System.Drawing.Point(80, 176);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(141, 20);
            this.txt_email.TabIndex = 0;
            this.txt_email.WordWrap = false;
            // 
            // txt_mdp
            // 
            this.txt_mdp.AcceptsTab = true;
            this.txt_mdp.Location = new System.Drawing.Point(80, 227);
            this.txt_mdp.Name = "txt_mdp";
            this.txt_mdp.PasswordChar = '*';
            this.txt_mdp.Size = new System.Drawing.Size(141, 20);
            this.txt_mdp.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 2;
            // 
            // lbl_bienvenue
            // 
            this.lbl_bienvenue.AutoSize = true;
            this.lbl_bienvenue.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bienvenue.Location = new System.Drawing.Point(79, 56);
            this.lbl_bienvenue.Name = "lbl_bienvenue";
            this.lbl_bienvenue.Size = new System.Drawing.Size(163, 31);
            this.lbl_bienvenue.TabIndex = 3;
            this.lbl_bienvenue.Text = "Bienvenue ! ";
            // 
            // lbl_instruction
            // 
            this.lbl_instruction.AutoSize = true;
            this.lbl_instruction.Location = new System.Drawing.Point(66, 103);
            this.lbl_instruction.Name = "lbl_instruction";
            this.lbl_instruction.Size = new System.Drawing.Size(186, 26);
            this.lbl_instruction.TabIndex = 4;
            this.lbl_instruction.Text = "Veuillez entrer vos identifiants pour \r\nvous connecter à votre espace client.";
            this.lbl_instruction.Click += new System.EventHandler(this.label3_Click);
            // 
            // btn_identifier
            // 
            this.btn_identifier.BackColor = System.Drawing.Color.LightGreen;
            this.btn_identifier.Location = new System.Drawing.Point(44, 261);
            this.btn_identifier.Name = "btn_identifier";
            this.btn_identifier.Size = new System.Drawing.Size(92, 27);
            this.btn_identifier.TabIndex = 5;
            this.btn_identifier.Text = "S\'identifier";
            this.btn_identifier.UseVisualStyleBackColor = false;
            this.btn_identifier.Click += new System.EventHandler(this.btn_identifier_Click);
            // 
            // btn_creer_compte
            // 
            this.btn_creer_compte.AutoSize = true;
            this.btn_creer_compte.Location = new System.Drawing.Point(180, 263);
            this.btn_creer_compte.Name = "btn_creer_compte";
            this.btn_creer_compte.Size = new System.Drawing.Size(95, 25);
            this.btn_creer_compte.TabIndex = 6;
            this.btn_creer_compte.Text = "Créer un compte";
            this.btn_creer_compte.UseVisualStyleBackColor = true;
            this.btn_creer_compte.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_identifier_admin
            // 
            this.btn_identifier_admin.BackColor = System.Drawing.Color.LightGreen;
            this.btn_identifier_admin.Location = new System.Drawing.Point(44, 310);
            this.btn_identifier_admin.Name = "btn_identifier_admin";
            this.btn_identifier_admin.Size = new System.Drawing.Size(92, 38);
            this.btn_identifier_admin.TabIndex = 7;
            this.btn_identifier_admin.Text = "S\'identifier en tant qu\'admin";
            this.btn_identifier_admin.UseVisualStyleBackColor = false;
            this.btn_identifier_admin.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_mdp_oublie
            // 
            this.btn_mdp_oublie.BackColor = System.Drawing.Color.Transparent;
            this.btn_mdp_oublie.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btn_mdp_oublie.Location = new System.Drawing.Point(180, 318);
            this.btn_mdp_oublie.Name = "btn_mdp_oublie";
            this.btn_mdp_oublie.Size = new System.Drawing.Size(123, 23);
            this.btn_mdp_oublie.TabIndex = 8;
            this.btn_mdp_oublie.Text = "Mot de passe oublié ?";
            this.btn_mdp_oublie.UseVisualStyleBackColor = false;
            this.btn_mdp_oublie.Click += new System.EventHandler(this.btn_mdp_oublie_Click);
            // 
            // lbl_mail
            // 
            this.lbl_mail.AutoSize = true;
            this.lbl_mail.Enabled = false;
            this.lbl_mail.Location = new System.Drawing.Point(82, 161);
            this.lbl_mail.Name = "lbl_mail";
            this.lbl_mail.Size = new System.Drawing.Size(66, 13);
            this.lbl_mail.TabIndex = 9;
            this.lbl_mail.Text = "Adresse mail";
            // 
            // lbl_mdp
            // 
            this.lbl_mdp.AutoSize = true;
            this.lbl_mdp.Enabled = false;
            this.lbl_mdp.Location = new System.Drawing.Point(82, 211);
            this.lbl_mdp.Name = "lbl_mdp";
            this.lbl_mdp.Size = new System.Drawing.Size(71, 13);
            this.lbl_mdp.TabIndex = 10;
            this.lbl_mdp.Text = "Mot de passe";
            // 
            // frm_FenetreDeConnexion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(315, 389);
            this.Controls.Add(this.lbl_mdp);
            this.Controls.Add(this.lbl_mail);
            this.Controls.Add(this.btn_mdp_oublie);
            this.Controls.Add(this.btn_identifier_admin);
            this.Controls.Add(this.btn_creer_compte);
            this.Controls.Add(this.btn_identifier);
            this.Controls.Add(this.lbl_instruction);
            this.Controls.Add(this.lbl_bienvenue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_mdp);
            this.Controls.Add(this.txt_email);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_FenetreDeConnexion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Connexion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_mdp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_bienvenue;
        private System.Windows.Forms.Label lbl_instruction;
        private System.Windows.Forms.Button btn_identifier;
        private System.Windows.Forms.Button btn_creer_compte;
        private System.Windows.Forms.Button btn_identifier_admin;
        private System.Windows.Forms.Button btn_mdp_oublie;
        private System.Windows.Forms.Label lbl_mail;
        private System.Windows.Forms.Label lbl_mdp;
    }
}