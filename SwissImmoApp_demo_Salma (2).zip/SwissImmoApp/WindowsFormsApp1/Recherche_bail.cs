﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class frm_Recherche_bail : Form
    {
        public frm_Recherche_bail()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void rdo_animaux_non_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            lbl_montant.Text = "Vous désirez trouver un bien d'une valeur de location de : " + trb_loyer.Value + " CHF.- par mois";
        }

        private void rdo_acheter_CheckedChanged(object sender, EventArgs e)
        {
            lbl_montant.Text = "";
            if (rdo_acheter.Checked) { trb_loyer.Hide(); txt_indication.Text = "Veuillez indiquer votre budget : "; txt_budget.Visible = true;
                
            }
        }

        private void rdo_location_CheckedChanged(object sender, EventArgs e)
        {
            lbl_montant.Text = "";
            if (rdo_location.Checked) { trb_loyer.Show(); txt_indication.Text = "Veuillez s'il vous plaît indiquer un prix (de location/mois)"; txt_budget.Visible = false; }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            lbl_montant.Text = "";
            if (txt_budget.Text != null) {
                lbl_montant.Text = "Vous désirez trouver un bien d'une valeur d'achat de : " + txt_budget.Text + " CHF.-";
            }
        }
    }
}
