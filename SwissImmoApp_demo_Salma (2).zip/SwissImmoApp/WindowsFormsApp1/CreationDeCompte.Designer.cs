﻿
namespace WindowsFormsApp1
{
    partial class frm_CreationDeCompte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_CreationDeCompte));
            this.lbl_bienvenue = new System.Windows.Forms.Label();
            this.lbl_instructions = new System.Windows.Forms.Label();
            this.cmb_civilite = new System.Windows.Forms.ComboBox();
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.txt_prenom = new System.Windows.Forms.TextBox();
            this.txt_telephone = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_confirmerMotDePasse = new System.Windows.Forms.TextBox();
            this.txt_motDePasse = new System.Windows.Forms.TextBox();
            this.lbl_mdp = new System.Windows.Forms.Label();
            this.lbl_confirmer_mdp = new System.Windows.Forms.Label();
            this.chk_conditions = new System.Windows.Forms.CheckBox();
            this.btn_valider_inscription = new System.Windows.Forms.Button();
            this.llbNom = new System.Windows.Forms.Label();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_telephone = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_bienvenue
            // 
            this.lbl_bienvenue.AutoSize = true;
            this.lbl_bienvenue.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_bienvenue.Location = new System.Drawing.Point(84, 9);
            this.lbl_bienvenue.Name = "lbl_bienvenue";
            this.lbl_bienvenue.Size = new System.Drawing.Size(317, 25);
            this.lbl_bienvenue.TabIndex = 0;
            this.lbl_bienvenue.Text = "Bienvenue sur SwissImmo app !";
            // 
            // lbl_instructions
            // 
            this.lbl_instructions.AutoSize = true;
            this.lbl_instructions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_instructions.Location = new System.Drawing.Point(120, 47);
            this.lbl_instructions.Name = "lbl_instructions";
            this.lbl_instructions.Size = new System.Drawing.Size(248, 32);
            this.lbl_instructions.TabIndex = 1;
            this.lbl_instructions.Text = "Afin de réaliser votre inscription\r\nVeuillez compléter les champs suivants :";
            this.lbl_instructions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmb_civilite
            // 
            this.cmb_civilite.FormattingEnabled = true;
            this.cmb_civilite.Items.AddRange(new object[] {
            "Mme",
            "Mr"});
            this.cmb_civilite.Location = new System.Drawing.Point(44, 120);
            this.cmb_civilite.Name = "cmb_civilite";
            this.cmb_civilite.Size = new System.Drawing.Size(144, 21);
            this.cmb_civilite.TabIndex = 2;
            this.cmb_civilite.Text = "Civilité";
            this.cmb_civilite.SelectedIndexChanged += new System.EventHandler(this.cmb_civilite_SelectedIndexChanged);
            // 
            // txt_nom
            // 
            this.txt_nom.AcceptsTab = true;
            this.txt_nom.Location = new System.Drawing.Point(44, 176);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(143, 20);
            this.txt_nom.TabIndex = 3;
            // 
            // txt_prenom
            // 
            this.txt_prenom.AcceptsTab = true;
            this.txt_prenom.Location = new System.Drawing.Point(258, 176);
            this.txt_prenom.Name = "txt_prenom";
            this.txt_prenom.Size = new System.Drawing.Size(143, 20);
            this.txt_prenom.TabIndex = 4;
            this.txt_prenom.TextChanged += new System.EventHandler(this.txt_prenom_TextChanged);
            // 
            // txt_telephone
            // 
            this.txt_telephone.AcceptsTab = true;
            this.txt_telephone.Location = new System.Drawing.Point(258, 232);
            this.txt_telephone.Name = "txt_telephone";
            this.txt_telephone.Size = new System.Drawing.Size(143, 20);
            this.txt_telephone.TabIndex = 5;
            this.txt_telephone.TextChanged += new System.EventHandler(this.txt_telephone_TextChanged);
            // 
            // txt_email
            // 
            this.txt_email.AcceptsTab = true;
            this.txt_email.Location = new System.Drawing.Point(44, 232);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(143, 20);
            this.txt_email.TabIndex = 6;
            // 
            // txt_confirmerMotDePasse
            // 
            this.txt_confirmerMotDePasse.AcceptsTab = true;
            this.txt_confirmerMotDePasse.Location = new System.Drawing.Point(258, 299);
            this.txt_confirmerMotDePasse.Name = "txt_confirmerMotDePasse";
            this.txt_confirmerMotDePasse.PasswordChar = '*';
            this.txt_confirmerMotDePasse.Size = new System.Drawing.Size(143, 20);
            this.txt_confirmerMotDePasse.TabIndex = 7;
            // 
            // txt_motDePasse
            // 
            this.txt_motDePasse.AcceptsTab = true;
            this.txt_motDePasse.Location = new System.Drawing.Point(44, 299);
            this.txt_motDePasse.Name = "txt_motDePasse";
            this.txt_motDePasse.PasswordChar = '*';
            this.txt_motDePasse.Size = new System.Drawing.Size(143, 20);
            this.txt_motDePasse.TabIndex = 8;
            // 
            // lbl_mdp
            // 
            this.lbl_mdp.AutoSize = true;
            this.lbl_mdp.Location = new System.Drawing.Point(41, 283);
            this.lbl_mdp.Name = "lbl_mdp";
            this.lbl_mdp.Size = new System.Drawing.Size(71, 13);
            this.lbl_mdp.TabIndex = 9;
            this.lbl_mdp.Text = "Mot de passe";
            // 
            // lbl_confirmer_mdp
            // 
            this.lbl_confirmer_mdp.AutoSize = true;
            this.lbl_confirmer_mdp.Location = new System.Drawing.Point(255, 283);
            this.lbl_confirmer_mdp.Name = "lbl_confirmer_mdp";
            this.lbl_confirmer_mdp.Size = new System.Drawing.Size(128, 13);
            this.lbl_confirmer_mdp.TabIndex = 10;
            this.lbl_confirmer_mdp.Text = "Confirmer le mot de passe";
            // 
            // chk_conditions
            // 
            this.chk_conditions.AutoSize = true;
            this.chk_conditions.Location = new System.Drawing.Point(44, 350);
            this.chk_conditions.Name = "chk_conditions";
            this.chk_conditions.Size = new System.Drawing.Size(188, 17);
            this.chk_conditions.TabIndex = 11;
            this.chk_conditions.Text = "J\'accepte les conditions générales";
            this.chk_conditions.UseVisualStyleBackColor = true;
            // 
            // btn_valider_inscription
            // 
            this.btn_valider_inscription.BackColor = System.Drawing.Color.Lime;
            this.btn_valider_inscription.Location = new System.Drawing.Point(44, 393);
            this.btn_valider_inscription.Name = "btn_valider_inscription";
            this.btn_valider_inscription.Size = new System.Drawing.Size(143, 33);
            this.btn_valider_inscription.TabIndex = 12;
            this.btn_valider_inscription.Text = "Valider mon inscription";
            this.btn_valider_inscription.UseVisualStyleBackColor = false;
            this.btn_valider_inscription.Click += new System.EventHandler(this.button1_Click);
            // 
            // llbNom
            // 
            this.llbNom.AutoSize = true;
            this.llbNom.Location = new System.Drawing.Point(41, 160);
            this.llbNom.Name = "llbNom";
            this.llbNom.Size = new System.Drawing.Size(29, 13);
            this.llbNom.TabIndex = 13;
            this.llbNom.Text = "Nom";
            // 
            // lblPrenom
            // 
            this.lblPrenom.AutoSize = true;
            this.lblPrenom.Location = new System.Drawing.Point(255, 160);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(43, 13);
            this.lblPrenom.TabIndex = 14;
            this.lblPrenom.Text = "Prénom";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Location = new System.Drawing.Point(41, 216);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(66, 13);
            this.lbl_Email.TabIndex = 15;
            this.lbl_Email.Text = "Adresse mail";
            // 
            // lbl_telephone
            // 
            this.lbl_telephone.AutoSize = true;
            this.lbl_telephone.Location = new System.Drawing.Point(255, 216);
            this.lbl_telephone.Name = "lbl_telephone";
            this.lbl_telephone.Size = new System.Drawing.Size(58, 13);
            this.lbl_telephone.TabIndex = 16;
            this.lbl_telephone.Text = "Téléphone";
            // 
            // frm_CreationDeCompte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 495);
            this.Controls.Add(this.lbl_telephone);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.lblPrenom);
            this.Controls.Add(this.llbNom);
            this.Controls.Add(this.btn_valider_inscription);
            this.Controls.Add(this.chk_conditions);
            this.Controls.Add(this.lbl_confirmer_mdp);
            this.Controls.Add(this.lbl_mdp);
            this.Controls.Add(this.txt_motDePasse);
            this.Controls.Add(this.txt_confirmerMotDePasse);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_telephone);
            this.Controls.Add(this.txt_prenom);
            this.Controls.Add(this.txt_nom);
            this.Controls.Add(this.cmb_civilite);
            this.Controls.Add(this.lbl_instructions);
            this.Controls.Add(this.lbl_bienvenue);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_CreationDeCompte";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "creationDeCompte";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_bienvenue;
        private System.Windows.Forms.Label lbl_instructions;
        private System.Windows.Forms.ComboBox cmb_civilite;
        private System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.TextBox txt_prenom;
        private System.Windows.Forms.TextBox txt_telephone;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_confirmerMotDePasse;
        private System.Windows.Forms.TextBox txt_motDePasse;
        private System.Windows.Forms.Label lbl_mdp;
        private System.Windows.Forms.Label lbl_confirmer_mdp;
        private System.Windows.Forms.CheckBox chk_conditions;
        private System.Windows.Forms.Button btn_valider_inscription;
        private System.Windows.Forms.Label llbNom;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.Label lbl_telephone;
    }
}