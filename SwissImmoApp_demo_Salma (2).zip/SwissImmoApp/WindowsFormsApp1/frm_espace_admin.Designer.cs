﻿
namespace WindowsFormsApp1
{
    partial class frm_espace_admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_espace_admin));
            this.btn_insertion = new System.Windows.Forms.Button();
            this.btn_supprimer = new System.Windows.Forms.Button();
            this.lbl_titre1 = new System.Windows.Forms.Label();
            this.lbl_civilite = new System.Windows.Forms.Label();
            this.lbl_telephone = new System.Windows.Forms.Label();
            this.lbl_email = new System.Windows.Forms.Label();
            this.lbl_prenom = new System.Windows.Forms.Label();
            this.lbl_nom = new System.Windows.Forms.Label();
            this.lbl_message = new System.Windows.Forms.Label();
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.txt_prenom = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_telephone = new System.Windows.Forms.TextBox();
            this.cmb_civilite = new System.Windows.Forms.ComboBox();
            this.dataSet1 = new WindowsFormsApp1.DataSet1();
            this.vW_UTILISATEURSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vW_UTILISATEURSTableAdapter = new WindowsFormsApp1.DataSet1TableAdapters.VW_UTILISATEURSTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.DataSet1TableAdapters.TableAdapterManager();
            this.vW_UTILISATEURSBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.vW_UTILISATEURSBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.swissImmoDS = new WindowsFormsApp1.SwissImmoDS();
            this.vW_UTILISATEURSBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.vW_UTILISATEURSTableAdapter1 = new WindowsFormsApp1.SwissImmoDSTableAdapters.VW_UTILISATEURSTableAdapter();
            this.tableAdapterManager1 = new WindowsFormsApp1.SwissImmoDSTableAdapters.TableAdapterManager();
            this.lbl_titre2 = new System.Windows.Forms.Label();
            this.vW_BIENSBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.vW_BIENSTableAdapter = new WindowsFormsApp1.SwissImmoDSTableAdapters.VW_BIENSTableAdapter();
            this.vW_BIENSDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vW_UTILISATEURSDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSBindingNavigator)).BeginInit();
            this.vW_UTILISATEURSBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.swissImmoDS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_BIENSBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_BIENSDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_insertion
            // 
            this.btn_insertion.Location = new System.Drawing.Point(615, 318);
            this.btn_insertion.Name = "btn_insertion";
            this.btn_insertion.Size = new System.Drawing.Size(106, 44);
            this.btn_insertion.TabIndex = 1;
            this.btn_insertion.Text = "&Insérer";
            this.btn_insertion.UseVisualStyleBackColor = true;
            this.btn_insertion.Click += new System.EventHandler(this.btn_insertion_Click);
            // 
            // btn_supprimer
            // 
            this.btn_supprimer.BackColor = System.Drawing.Color.Red;
            this.btn_supprimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_supprimer.ForeColor = System.Drawing.Color.White;
            this.btn_supprimer.Location = new System.Drawing.Point(615, 377);
            this.btn_supprimer.Name = "btn_supprimer";
            this.btn_supprimer.Size = new System.Drawing.Size(106, 44);
            this.btn_supprimer.TabIndex = 2;
            this.btn_supprimer.Text = "&Supprimer";
            this.btn_supprimer.UseVisualStyleBackColor = false;
            this.btn_supprimer.Click += new System.EventHandler(this.btn_supprimer_Click);
            // 
            // lbl_titre1
            // 
            this.lbl_titre1.AutoSize = true;
            this.lbl_titre1.Enabled = false;
            this.lbl_titre1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titre1.Location = new System.Drawing.Point(58, 31);
            this.lbl_titre1.Name = "lbl_titre1";
            this.lbl_titre1.Size = new System.Drawing.Size(180, 20);
            this.lbl_titre1.TabIndex = 3;
            this.lbl_titre1.Text = "Liste des utilisateurs ";
            // 
            // lbl_civilite
            // 
            this.lbl_civilite.AutoSize = true;
            this.lbl_civilite.Enabled = false;
            this.lbl_civilite.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_civilite.Location = new System.Drawing.Point(59, 318);
            this.lbl_civilite.Name = "lbl_civilite";
            this.lbl_civilite.Size = new System.Drawing.Size(58, 15);
            this.lbl_civilite.TabIndex = 4;
            this.lbl_civilite.Text = "Civilité :";
            // 
            // lbl_telephone
            // 
            this.lbl_telephone.AutoSize = true;
            this.lbl_telephone.Enabled = false;
            this.lbl_telephone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telephone.Location = new System.Drawing.Point(370, 349);
            this.lbl_telephone.Name = "lbl_telephone";
            this.lbl_telephone.Size = new System.Drawing.Size(83, 15);
            this.lbl_telephone.TabIndex = 5;
            this.lbl_telephone.Text = "&Téléphone :";
            // 
            // lbl_email
            // 
            this.lbl_email.AutoSize = true;
            this.lbl_email.Enabled = false;
            this.lbl_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_email.Location = new System.Drawing.Point(370, 318);
            this.lbl_email.Name = "lbl_email";
            this.lbl_email.Size = new System.Drawing.Size(52, 15);
            this.lbl_email.TabIndex = 6;
            this.lbl_email.Text = "&Email :";
            // 
            // lbl_prenom
            // 
            this.lbl_prenom.AutoSize = true;
            this.lbl_prenom.Enabled = false;
            this.lbl_prenom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_prenom.Location = new System.Drawing.Point(177, 349);
            this.lbl_prenom.Name = "lbl_prenom";
            this.lbl_prenom.Size = new System.Drawing.Size(65, 15);
            this.lbl_prenom.TabIndex = 7;
            this.lbl_prenom.Text = "&Prénom :";
            // 
            // lbl_nom
            // 
            this.lbl_nom.AutoSize = true;
            this.lbl_nom.Enabled = false;
            this.lbl_nom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nom.Location = new System.Drawing.Point(177, 318);
            this.lbl_nom.Name = "lbl_nom";
            this.lbl_nom.Size = new System.Drawing.Size(45, 15);
            this.lbl_nom.TabIndex = 8;
            this.lbl_nom.Text = "&Nom :";
            // 
            // lbl_message
            // 
            this.lbl_message.AutoSize = true;
            this.lbl_message.Enabled = false;
            this.lbl_message.Location = new System.Drawing.Point(59, 393);
            this.lbl_message.Name = "lbl_message";
            this.lbl_message.Size = new System.Drawing.Size(0, 13);
            this.lbl_message.TabIndex = 9;
            // 
            // txt_nom
            // 
            this.txt_nom.Location = new System.Drawing.Point(228, 318);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(122, 20);
            this.txt_nom.TabIndex = 10;
            // 
            // txt_prenom
            // 
            this.txt_prenom.Location = new System.Drawing.Point(248, 349);
            this.txt_prenom.Name = "txt_prenom";
            this.txt_prenom.Size = new System.Drawing.Size(122, 20);
            this.txt_prenom.TabIndex = 11;
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(428, 317);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(122, 20);
            this.txt_email.TabIndex = 12;
            // 
            // txt_telephone
            // 
            this.txt_telephone.Location = new System.Drawing.Point(459, 349);
            this.txt_telephone.Name = "txt_telephone";
            this.txt_telephone.Size = new System.Drawing.Size(122, 20);
            this.txt_telephone.TabIndex = 13;
            // 
            // cmb_civilite
            // 
            this.cmb_civilite.FormattingEnabled = true;
            this.cmb_civilite.Items.AddRange(new object[] {
            "Mme",
            "Mr"});
            this.cmb_civilite.Location = new System.Drawing.Point(118, 316);
            this.cmb_civilite.Name = "cmb_civilite";
            this.cmb_civilite.Size = new System.Drawing.Size(53, 21);
            this.cmb_civilite.TabIndex = 14;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vW_UTILISATEURSBindingSource
            // 
            this.vW_UTILISATEURSBindingSource.DataMember = "VW_UTILISATEURS";
            this.vW_UTILISATEURSBindingSource.DataSource = this.dataSet1;
            // 
            // vW_UTILISATEURSTableAdapter
            // 
            this.vW_UTILISATEURSTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.SI_BIENIMMOBILIERTableAdapter = null;
            this.tableAdapterManager.SI_CONTRATLOCATIONTableAdapter = null;
            this.tableAdapterManager.SI_PERSONNETableAdapter = null;
            this.tableAdapterManager.SI_VISITETableAdapter = null;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.DataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // vW_UTILISATEURSBindingNavigator
            // 
            this.vW_UTILISATEURSBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.vW_UTILISATEURSBindingNavigator.BindingSource = this.vW_UTILISATEURSBindingSource;
            this.vW_UTILISATEURSBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.vW_UTILISATEURSBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.vW_UTILISATEURSBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.vW_UTILISATEURSBindingNavigatorSaveItem});
            this.vW_UTILISATEURSBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.vW_UTILISATEURSBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.vW_UTILISATEURSBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.vW_UTILISATEURSBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.vW_UTILISATEURSBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.vW_UTILISATEURSBindingNavigator.Name = "vW_UTILISATEURSBindingNavigator";
            this.vW_UTILISATEURSBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.vW_UTILISATEURSBindingNavigator.Size = new System.Drawing.Size(933, 25);
            this.vW_UTILISATEURSBindingNavigator.TabIndex = 15;
            this.vW_UTILISATEURSBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // vW_UTILISATEURSBindingNavigatorSaveItem
            // 
            this.vW_UTILISATEURSBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.vW_UTILISATEURSBindingNavigatorSaveItem.Enabled = false;
            this.vW_UTILISATEURSBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("vW_UTILISATEURSBindingNavigatorSaveItem.Image")));
            this.vW_UTILISATEURSBindingNavigatorSaveItem.Name = "vW_UTILISATEURSBindingNavigatorSaveItem";
            this.vW_UTILISATEURSBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.vW_UTILISATEURSBindingNavigatorSaveItem.Text = "Enregistrer les données";
            // 
            // swissImmoDS
            // 
            this.swissImmoDS.DataSetName = "SwissImmoDS";
            this.swissImmoDS.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // vW_UTILISATEURSBindingSource1
            // 
            this.vW_UTILISATEURSBindingSource1.DataMember = "VW_UTILISATEURS";
            this.vW_UTILISATEURSBindingSource1.DataSource = this.swissImmoDS;
            // 
            // vW_UTILISATEURSTableAdapter1
            // 
            this.vW_UTILISATEURSTableAdapter1.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.SI_BIENIMMOBILIERTableAdapter = null;
            this.tableAdapterManager1.SI_CONTRATLOCATIONTableAdapter = null;
            this.tableAdapterManager1.SI_PERSONNETableAdapter = null;
            this.tableAdapterManager1.SI_VISITETableAdapter = null;
            this.tableAdapterManager1.UpdateOrder = WindowsFormsApp1.SwissImmoDSTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // lbl_titre2
            // 
            this.lbl_titre2.AutoSize = true;
            this.lbl_titre2.Enabled = false;
            this.lbl_titre2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titre2.Location = new System.Drawing.Point(58, 445);
            this.lbl_titre2.Name = "lbl_titre2";
            this.lbl_titre2.Size = new System.Drawing.Size(140, 20);
            this.lbl_titre2.TabIndex = 17;
            this.lbl_titre2.Text = "Liste des biens  ";
            // 
            // vW_BIENSBindingSource
            // 
            this.vW_BIENSBindingSource.DataMember = "VW_BIENS";
            this.vW_BIENSBindingSource.DataSource = this.swissImmoDS;
            // 
            // vW_BIENSTableAdapter
            // 
            this.vW_BIENSTableAdapter.ClearBeforeFill = true;
            // 
            // vW_BIENSDataGridView
            // 
            this.vW_BIENSDataGridView.AutoGenerateColumns = false;
            this.vW_BIENSDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.vW_BIENSDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.vW_BIENSDataGridView.DataSource = this.vW_BIENSBindingSource;
            this.vW_BIENSDataGridView.Location = new System.Drawing.Point(62, 484);
            this.vW_BIENSDataGridView.Name = "vW_BIENSDataGridView";
            this.vW_BIENSDataGridView.Size = new System.Drawing.Size(659, 220);
            this.vW_BIENSDataGridView.TabIndex = 17;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NOMBRE_DE_PIECES";
            this.dataGridViewTextBoxColumn5.HeaderText = "NOMBRE_DE_PIECES";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "CODE_POSTAL";
            this.dataGridViewTextBoxColumn6.HeaderText = "CODE_POSTAL";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "VILLE";
            this.dataGridViewTextBoxColumn7.HeaderText = "VILLE";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "ADRESSE";
            this.dataGridViewTextBoxColumn8.HeaderText = "ADRESSE";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "TYPE_DE_BIEN";
            this.dataGridViewTextBoxColumn9.HeaderText = "TYPE_DE_BIEN";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // vW_UTILISATEURSDataGridView
            // 
            this.vW_UTILISATEURSDataGridView.AutoGenerateColumns = false;
            this.vW_UTILISATEURSDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.vW_UTILISATEURSDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.vW_UTILISATEURSDataGridView.DataSource = this.vW_UTILISATEURSBindingSource1;
            this.vW_UTILISATEURSDataGridView.Location = new System.Drawing.Point(62, 68);
            this.vW_UTILISATEURSDataGridView.Name = "vW_UTILISATEURSDataGridView";
            this.vW_UTILISATEURSDataGridView.Size = new System.Drawing.Size(659, 220);
            this.vW_UTILISATEURSDataGridView.TabIndex = 17;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "NOM";
            this.dataGridViewTextBoxColumn1.HeaderText = "NOM";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "PRENOM";
            this.dataGridViewTextBoxColumn2.HeaderText = "PRENOM";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "EMAIL";
            this.dataGridViewTextBoxColumn3.HeaderText = "EMAIL";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "TELEPHONE";
            this.dataGridViewTextBoxColumn4.HeaderText = "TELEPHONE";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // frm_espace_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 852);
            this.Controls.Add(this.vW_UTILISATEURSDataGridView);
            this.Controls.Add(this.vW_BIENSDataGridView);
            this.Controls.Add(this.lbl_titre2);
            this.Controls.Add(this.vW_UTILISATEURSBindingNavigator);
            this.Controls.Add(this.cmb_civilite);
            this.Controls.Add(this.txt_telephone);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_prenom);
            this.Controls.Add(this.txt_nom);
            this.Controls.Add(this.lbl_message);
            this.Controls.Add(this.lbl_nom);
            this.Controls.Add(this.lbl_prenom);
            this.Controls.Add(this.lbl_email);
            this.Controls.Add(this.lbl_telephone);
            this.Controls.Add(this.lbl_civilite);
            this.Controls.Add(this.lbl_titre1);
            this.Controls.Add(this.btn_supprimer);
            this.Controls.Add(this.btn_insertion);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm_espace_admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_espace_admin";
            this.Load += new System.EventHandler(this.frm_espace_admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSBindingNavigator)).EndInit();
            this.vW_UTILISATEURSBindingNavigator.ResumeLayout(false);
            this.vW_UTILISATEURSBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.swissImmoDS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_BIENSBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_BIENSDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vW_UTILISATEURSDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_insertion;
        private System.Windows.Forms.Button btn_supprimer;
        private System.Windows.Forms.Label lbl_titre1;
        private System.Windows.Forms.Label lbl_civilite;
        private System.Windows.Forms.Label lbl_telephone;
        private System.Windows.Forms.Label lbl_email;
        private System.Windows.Forms.Label lbl_prenom;
        private System.Windows.Forms.Label lbl_nom;
        private System.Windows.Forms.Label lbl_message;
        private System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.TextBox txt_prenom;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_telephone;
        private System.Windows.Forms.ComboBox cmb_civilite;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource vW_UTILISATEURSBindingSource;
        private DataSet1TableAdapters.VW_UTILISATEURSTableAdapter vW_UTILISATEURSTableAdapter;
        private DataSet1TableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator vW_UTILISATEURSBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton vW_UTILISATEURSBindingNavigatorSaveItem;
        private SwissImmoDS swissImmoDS;
        private System.Windows.Forms.BindingSource vW_UTILISATEURSBindingSource1;
        private SwissImmoDSTableAdapters.VW_UTILISATEURSTableAdapter vW_UTILISATEURSTableAdapter1;
        private SwissImmoDSTableAdapters.TableAdapterManager tableAdapterManager1;
        private System.Windows.Forms.Label lbl_titre2;
        private System.Windows.Forms.BindingSource vW_BIENSBindingSource;
        private SwissImmoDSTableAdapters.VW_BIENSTableAdapter vW_BIENSTableAdapter;
        private System.Windows.Forms.DataGridView vW_BIENSDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridView vW_UTILISATEURSDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    }
}