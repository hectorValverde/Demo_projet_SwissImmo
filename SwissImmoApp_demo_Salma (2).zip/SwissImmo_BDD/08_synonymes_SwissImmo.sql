-- ======================================================================
--  Script: 08_synonymes_SwissImmo.sql 
--  Objet : Cr�ation des synonymes de la base EasyCooking 
-- ======================================================================
CREATE OR REPLACE SYNONYM SwissImmo_user.vw_utilisateurs FOR SwissImmo_data.vw_utilisateurs;
CREATE OR REPLACE SYNONYM SwissImmo_user.vw_visites FOR SwissImmo_data.vw_visites;
CREATE OR REPLACE SYNONYM SwissImmo_user.vw_contrats_location FOR SwissImmo_data.vw_contrats_location;
CREATE OR REPLACE SYNONYM SwissImmo_user.vw_contrats_vente FOR SwissImmo_data.vw_contrats_vente;
CREATE OR REPLACE SYNONYM SwissImmo_user.package_SwissImmo FOR SwissImmo_data.package_SwissImmo;

CREATE OR REPLACE SYNONYM SwissImmo_user.sq_personne FOR SwissImmo_data.sq_personne;
CREATE OR REPLACE SYNONYM SwissImmo_user.sq_contrat_loc FOR SwissImmo_data.sq_contrat_loc;
CREATE OR REPLACE SYNONYM SwissImmo_user.sq_contrat_ven FOR SwissImmo_data.sq_contrat_ven;
CREATE OR REPLACE SYNONYM SwissImmo_user.sq_bienImmo FOR SwissImmo_data.sq_bienImmo;
CREATE OR REPLACE SYNONYM SwissImmo_user.sq_visites FOR SwissImmo_data.sq_visites;
