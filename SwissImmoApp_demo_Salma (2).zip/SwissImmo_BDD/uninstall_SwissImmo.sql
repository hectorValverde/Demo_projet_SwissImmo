--------------------------------------------------------------------------------------------
--Script : uninstall_SwissImmo.sql
--Objet  : Cr�ation des synonymes de la BDD d�monstration sur SGBD Oracle en Local (HEGLOCAL)
--------------------------------------------------------------------------------------------

-- Suppression des utilisateurs (CASCADE), r�les et profil
SPOOL .\Logs\uninstall_SwissImmo.log

--=============================================
--Suppression des r�les, utilisateurs et profil
--=============================================
--Suppression des utilisateurs
DROP USER SwissImmo_data CASCADE;
DROP USER SwissImmo_user CASCADE;

--Suppression des r�les
DROP ROLE role_SwissImmo_data CASCADE;
DROP ROLE role_SwissImmo_user CASCADE;

--Suppression du profil
DROP PROFILE SwissImmo_profil;

SPOOL OFF

EXIT;